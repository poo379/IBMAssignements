let express = require("express");
let app = express();
let data = require("./data/data.json");
// middlewares
// routes
app.get("/", function(req, res){
    //res.sendFile(__dirname+"/temp.html");
    //res.sendFile(__dirname+"/data/data.json")
    res.json(data);
});

app.listen(5050, "localhost");
console.log("server is now live on localhost:5050");