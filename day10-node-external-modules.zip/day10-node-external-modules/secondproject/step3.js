let fetch = require("fetch");
let fs = require("fs");

fetch.fetchUrl("https://www.ibm.com/in-en",function(error,meta,res){
    
    if(error){
        console.log("error",error);
    }else{
        fs.writeFile("temp.html",res,"utf8", function(error){
            if(error){
                console.log("error",error)
            }else{
                console.log("file created")
            }
        })
    }
})