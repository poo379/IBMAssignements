let fs = require("fs");
console.log(__dirname);
fs.mkdir("data",function(error){
    if(error){
        console.log("error ", error)
    }else{
        //console.log("directory is now created")
        //console.log(process.cwd() );
        process.chdir("data");
        setImmediate(function(){
            console.log(process.cwd());
            //console.log(__dirname);
            fs.writeFileSync("hello.txt","welcome to your life", "utf8");
//-------------------------------
            setTimeout(function(){
                fs.renameSync("hello.txt","ibm.txt");
            }, 2000)

            setTimeout(function(){
                console.log(fs.readFileSync("ibm.txt","utf-8"));
            },4000)

            setTimeout(function(){
                fs.unlinkSync("ibm.txt");
                process.chdir("../");
            },6000)

            setTimeout(function(){
                fs.rmdirSync("data");
                console.log("All clear");
            },8000)
           
        })
//--------------------------
    }
})