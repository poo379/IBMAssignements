let http = require("http");
let fs = require("fs");
let server = http.createServer(function (req, res) {
  /*res.write(`
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  </head>
  <body>
    <h1>
      IBM INDIA
    </h1>
    <P>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum aspernatur maiores unde mollitia ratione, dignissimos laboriosam praesentium doloremque architecto enim ipsum pariatur, eius repellendus quisquam autem quam dolorum provident reiciendis!
    </P>
    <P>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum aspernatur maiores unde mollitia ratione, dignissimos laboriosam praesentium doloremque architecto enim ipsum pariatur, eius repellendus quisquam autem quam dolorum provident reiciendis!
    </P>
    <P>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum aspernatur maiores unde mollitia ratione, dignissimos laboriosam praesentium doloremque architecto enim ipsum pariatur, eius repellendus quisquam autem quam dolorum provident reiciendis!
    </P>
  
  </body>
  </html>
   `);
  res.end();*/
  

  res.write(fs.readFileSync("temp.html", "utf-8"));
  res.end();
});

server.listen(5050, "localhost", function (error) {
  if (error) {
    console.log("error", error);
  } else {
    console.log("server is now on localhost : 5050");
  }
});
