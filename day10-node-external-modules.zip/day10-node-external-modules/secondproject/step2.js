/*let EventEmitter = require("events").EventEmitter;

let ee = new EventEmitter();

ee.addListener("ibmEvent", ibmEventHandler)
function ibmEventHandler(){
    console.log("ibm event happened");
}

ee.emit("ibmEvent");
setTimeout(function(){
    ee.emit("ibmEvent");
},2000);*/

//create an event that happens once every 2 seconds for 5 seconds
let EventEmitter = require("events").EventEmitter;

let ee = new EventEmitter();

var count = 0;
ee.addListener("ibmEvent", ibmEventHandler)
function ibmEventHandler(){
    console.log("ibm event happened", count);
}

var ci = setInterval(function(){
    if(count < 5){
        ee.emit("ibmEvent");
        count++;
    }else{
        clearInterval(ci);
    }
},2000);
